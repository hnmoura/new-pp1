console.log("ola mundo");
fetch('http://localhost:3000/jogos')
.then(req => req.json())
.then((data) => mostrarjogos(data));


function mostrarjogos(jogos){
    const htmljogos = jogos.map((jogos) => 
        
        `   

        <h2>${jogos.titulo}</h2>

    <h4>preco: ${jogos.preco}</h4>

    <img src="${jogos.imagem}" alt="imagens/fifa.jpeg" />
    <button>Adicionar ao carrinho</button>
    `

);
document.getElementById('app').innerHTML = htmljogos;
}